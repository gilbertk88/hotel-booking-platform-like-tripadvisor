
		var BASE_URL = '/hotel';
		var params = {
			change_search_ajax: 1
		}
	
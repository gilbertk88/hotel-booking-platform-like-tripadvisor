<?php

Yii::import('ext.eoauth.*');
Yii::import('ext.eoauth.lib.*');

class EOAuthComponent extends CComponent {
}
?>
